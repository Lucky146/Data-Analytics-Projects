use Walmart_sales;
Task 1: Identifying the Top Branch by Sales Growth Rate (6 Marks)
        Walmart wants to identify which branch has exhibited the highest sales growth
        over time. Analyze the total sales for each branch and compare the growth
        rate across months to find the top performer.

SELECT
    Branch,
    AVG((Monthly_Total_Sales - Previous_Month_Sales) / Previous_Month_Sales * 100) AS Average_Growth_Rate
FROM (
    SELECT
        Branch,
        DATE_FORMAT(STR_TO_DATE(Date, '%d-%m-%Y'), '%Y-%m') AS YearMonth,
        SUM(Total) AS Monthly_Total_Sales,
        LAG(SUM(Total)) OVER (PARTITION BY Branch ORDER BY DATE_FORMAT(STR_TO_DATE(Date, '%d-%m-%Y'), '%Y-%m')) AS Previous_Month_Sales
    FROM Walmart_sales
    GROUP BY Branch, YearMonth
) AS Sales_With_Growth
WHERE Previous_Month_Sales IS NOT NULL
GROUP BY Branch
ORDER BY Average_Growth_Rate DESC
LIMIT 1;


