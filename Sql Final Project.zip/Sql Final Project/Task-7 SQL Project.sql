Task 7: Best Product Line by Customer Type (6 Marks)
Walmart wants to know which product lines are preferred by different customer 
types(Member vs. Normal).

WITH Product_Line_Sales AS (
    SELECT
        `Customer Type`,
        `Product Line`,
        SUM(`Total`) AS Total_Sales
    FROM
        Walmart_sales
    GROUP BY
        `Customer Type`, `Product Line`
),
Best_Product_Line AS (
    SELECT
        `Customer Type`,
        `Product Line`,
        Total_Sales,
        RANK() OVER (PARTITION BY `Customer Type` ORDER BY Total_Sales DESC) AS Ranked
    FROM
        Product_Line_Sales
)
SELECT
    `Customer Type`,
    `Product Line` AS Best_Product_Line,
    Total_Sales
FROM
    Best_Product_Line
WHERE
    Ranked = 1;
