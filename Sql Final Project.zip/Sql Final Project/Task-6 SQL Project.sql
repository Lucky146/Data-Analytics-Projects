Task 6: Monthly Sales Distribution by Gender (6 Marks)
Walmart wants to understand the sales distribution between male and female customers on a 
monthly basis.

SELECT 
    DATE_FORMAT(STR_TO_DATE(`Date`, '%d-%m-%Y'), '%Y-%m') AS Month,
    Gender,
    SUM(`Total`) AS Total_Sales
FROM 
    Walmart_sales
GROUP BY 
    Month, Gender
ORDER BY 
    Month, Gender;

