Task 9: Finding Top 5 Customers by Sales Volume (6 Marks)
Walmart wants to reward its top 5 customers who have generated the most sales Revenue.

WITH Customer_Sales AS (
    SELECT
        `Customer ID`,
        SUM(`Total`) AS Total_Sales
    FROM 
        Walmart_sales
    GROUP BY 
        `Customer ID`
),
Ranked_Customers AS (
    SELECT
        `Customer ID`,
        Total_Sales,
        RANK() OVER (ORDER BY Total_Sales DESC) AS Ranked
    FROM 
        Customer_Sales
)
SELECT
    `Customer ID`,
    Total_Sales
FROM 
    Ranked_Customers
WHERE 
    Ranked <= 5;

