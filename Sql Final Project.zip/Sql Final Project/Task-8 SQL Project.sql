Task 8: Identifying Repeat Customers (6 Marks)
Walmart needs to identify customers who made repeat purchases within a specific time 
frame (e.g., within 30 days).

SELECT 
    ws1.`Customer ID`,
    ws1.`Date` AS First_Purchase_Date,
    ws2.`Date` AS Repeat_Purchase_Date,
    DATEDIFF(STR_TO_DATE(ws2.`Date`, '%d-%m-%Y'), STR_TO_DATE(ws1.`Date`, '%d-%m-%Y')) AS Days_Between
FROM 
    Walmart_sales ws1
JOIN 
    Walmart_sales ws2
    ON ws1.`Customer ID` = ws2.`Customer ID` 
    AND STR_TO_DATE(ws2.`Date`, '%d-%m-%Y') > STR_TO_DATE(ws1.`Date`, '%d-%m-%Y')
WHERE 
    DATEDIFF(STR_TO_DATE(ws2.`Date`, '%d-%m-%Y'), STR_TO_DATE(ws1.`Date`, '%d-%m-%Y')) <= 30
ORDER BY 
    ws1.`Customer ID`, First_Purchase_Date, Repeat_Purchase_Date;

