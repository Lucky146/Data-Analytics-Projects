Task 4: Detecting Anomalies in Sales Transactions (6 Marks)
Walmart suspects that some transactions have unusually high or low sales compared to the 
average for the product line. Identify these anomalies.

WITH Product_Line_Stats AS (
    SELECT
        `Product Line`,
        AVG(`Total`) AS Avg_Sales,
        STDDEV(`Total`) AS Std_Dev_Sales
    FROM Walmart_sales
    GROUP BY `Product Line`
),
Anomalies AS (
    SELECT
        ws.`Invoice ID`,
        ws.`Branch`,
        ws.`Product Line`,
        ws.`Total`,
        pls.Avg_Sales,
        pls.Std_Dev_Sales,
        CASE
            WHEN ws.`Total` > pls.Avg_Sales + 1.5 * pls.Std_Dev_Sales THEN 'High Anomaly'
            WHEN ws.`Total` < pls.Avg_Sales - 1.5 * pls.Std_Dev_Sales THEN 'Low Anomaly'
            ELSE 'Normal'
        END AS Anomaly_Flag
    FROM
        Walmart_sales ws
    JOIN
        Product_Line_Stats pls
        ON ws.`Product Line` = pls.`Product Line`
)
SELECT *
FROM Anomalies
WHERE Anomaly_Flag IN ('High Anomaly', 'Low Anomaly');


