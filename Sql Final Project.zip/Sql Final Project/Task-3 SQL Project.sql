Task 3: Analyzing Customer Segmentation Based on Spending (6 Marks)
Walmart wants to segment customers based on their average spending behavior. Classify customers into three
tiers: High, Medium, and Low spenders based on their total purchase amounts.

SELECT 
    `Customer ID`,
    SUM(`Total`) AS Total_Spending,
    CASE
        WHEN SUM(`Total`) > 1000 THEN 'High Spender'
        WHEN SUM(`Total`) BETWEEN 500 AND 1000 THEN 'Medium Spender'
        ELSE 'Low Spender'
    END AS Spending_Tier
FROM 
    Walmart_sales
GROUP BY 
    `Customer ID`
ORDER BY 
    Total_Spending DESC;
