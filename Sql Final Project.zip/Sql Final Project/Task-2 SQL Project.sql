Task 2: Finding the Most Profitable Product Line for Each Branch (6 Marks)
Walmart needs to determine which product line contributes the highest profit to each branch.The profit margin
should be calculated based on the difference between the gross income and cost of goods sold.

-- Describe walmart_Sales;

SELECT
    Branch,
    `Product Line`,
    SUM(`Gross Income` - COGS) AS Total_Profit
FROM Walmart_sales
GROUP BY Branch, `Product Line`
ORDER BY Branch, Total_Profit DESC;
