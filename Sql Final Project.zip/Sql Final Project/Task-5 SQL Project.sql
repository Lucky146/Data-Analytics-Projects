Task 5: Most Popular Payment Method by City (6 Marks)
        Walmart needs to determine the most popular payment method in each city to tailor
		marketing strategies.
        
      WITH Payment_Counts AS (
    SELECT 
        City,
        Payment,
        COUNT(*) AS Payment_Count
    FROM 
        Walmart_sales
    GROUP BY 
        City, Payment
),
Most_Popular_Payment AS (
    SELECT 
        City,
        Payment,
        Payment_Count,
        RANK() OVER (PARTITION BY City ORDER BY Payment_Count DESC) AS Rank
    FROM 
        Payment_Counts
)
SELECT 
    City,
    Payment AS Most_Popular_Payment,
    Payment_Count
FROM 
    Most_Popular_Payment
WHERE 
    Rank = 1;
